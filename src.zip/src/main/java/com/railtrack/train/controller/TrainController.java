package com.railtrack.train.controller;

import com.railtrack.common.dto.RailRadarResponse;
import com.railtrack.train.dto.response.TrainSearchResponse;
import com.railtrack.train.service.TrainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/v1/train")
@Tag(name = "Train APIs")
public class TrainController {

    private final TrainService trainService;

    public TrainController(TrainService trainService) {
        this.trainService = trainService;
    }

    @Operation(summary = "Search trains between stations")
    @GetMapping("/between-stations")
    public ResponseEntity<TrainSearchResponse> searchTrains(

            @RequestParam
            @NotBlank(message = "Source station is required")
            String from,

            @RequestParam
            @NotBlank(message = "Destination station is required")
            String to,

            @RequestParam
            @NotNull(message = "Journey date is required")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate journeyDate,

            @RequestParam
            @NotBlank(message = "Travel class is required")
            String travelClass,

            @RequestParam
            @NotBlank(message = "Quota is required")
            String quota) {

        return ResponseEntity.ok(
                trainService.searchTrains(
                        from,
                        to,
                        journeyDate,
                        travelClass,
                        quota));
    }

    @Operation(summary = "Train Details")
    @GetMapping("/details/{trainNumber}")
    public ResponseEntity<RailRadarResponse> trainDetails(

            @PathVariable String trainNumber,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate journeyDate,

            @RequestParam(required = false)
            String dataType,

            @RequestParam(required = false)
            String dataProvider,

            @RequestParam(required = false)
            String userId) {

        return ResponseEntity.ok(
                trainService.trainDetails(
                        trainNumber,
                        journeyDate,
                        dataType,
                        dataProvider,
                        userId));
    }

    @Operation(summary = "Live Train Status")
    @GetMapping("/live/{trainNumber}")
    public ResponseEntity<RailRadarResponse> liveTrain(

            @PathVariable String trainNumber,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date,

            @RequestParam(defaultValue = "false")
            boolean haltsOnly,

            @RequestParam(defaultValue = "false")
            boolean geometry,

            @RequestParam(defaultValue = "polyline")
            String format,

            @RequestParam(defaultValue = "false")
            boolean includeCoordinates) {

        return ResponseEntity.ok(
                trainService.liveTrain(
                        trainNumber,
                        date,
                        haltsOnly,
                        geometry,
                        format,
                        includeCoordinates));
    }

    @Operation(summary = "Train Route Geometry")
    @GetMapping("/route/{trainNumber}")
    public ResponseEntity<RailRadarResponse> route(

            @PathVariable String trainNumber,

            @RequestParam(defaultValue = "polyline")
            String format,

            @RequestParam(defaultValue = "true")
            boolean stops) {

        return ResponseEntity.ok(
                trainService.route(
                        trainNumber,
                        format,
                        stops));
    }
}