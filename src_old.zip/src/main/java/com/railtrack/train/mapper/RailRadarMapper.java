package com.railtrack.train.mapper;

import com.fasterxml.jackson.databind.JsonNode;
import com.railtrack.common.dto.RailRadarResponse;
import com.railtrack.train.dto.response.CurrentLocationResponse;
import com.railtrack.train.dto.response.LiveTrainResponse;
import com.railtrack.train.dto.response.StationResponse;
import com.railtrack.train.dto.response.TrainDetailsResponse;
import org.springframework.stereotype.Component;
import com.railtrack.train.dto.response.RouteStationResponse;
import com.railtrack.train.dto.response.TrainRouteResponse;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component
public class RailRadarMapper {

    /*
     * ==========================
     * TRAIN DETAILS
     * ==========================
     */

    public TrainDetailsResponse mapTrainDetails(RailRadarResponse response) {

        if (response == null ||
                !response.success() ||
                response.data() == null ||
                response.data().get("train") == null) {
            return null;
        }

        JsonNode train = response.data().get("train");

        return TrainDetailsResponse.builder()
                .trainNumber(getText(train, "trainNumber"))
                .trainName(getText(train, "trainName"))
                .trainType(getText(train, "type"))

                .sourceStationCode(getText(train, "sourceStationCode"))
                .sourceStationName(getText(train, "sourceStationName"))

                .destinationStationCode(getText(train, "destinationStationCode"))
                .destinationStationName(getText(train, "destinationStationName"))

                .distanceKm(getDouble(train, "distanceKm"))
                .travelTimeMinutes(getInt(train, "travelTimeMinutes"))
                .totalHalts(getInt(train, "totalHalts"))

                .avgSpeedKmph(getDouble(train, "avgSpeedKmph"))
                .returnTrainNumber(getText(train, "returnTrainNumber"))

                .runningDays(extractRunningDays(train))
                .build();
    }

    /*
     * ==========================
     * LIVE TRAIN
     * ==========================
     */

    public LiveTrainResponse mapLiveTrain(RailRadarResponse response) {

        if (response == null ||
                !response.success() ||
                response.data() == null) {
            return null;
        }

        JsonNode data = response.data();

        JsonNode train = data.get("train");
        JsonNode currentLocation = data.get("currentLocation");
        JsonNode previousHalt = data.get("previousHalt");
        JsonNode nextHalt = data.get("nextHalt");

        return LiveTrainResponse.builder()

                .trainNumber(getText(data, "trainNumber"))
                .trainName(getText(data, "trainName"))
                .startDate(getText(data, "startDate"))
                .status(getText(data, "status"))
                .lastUpdatedAt(getText(data, "lastUpdatedAt"))

                .delayMinutes(getInt(data, "delayMinutes"))
                .trackingMode(getText(data, "trackingMode"))
                .isLive(getBoolean(data, "isLive"))

                .trainType(getText(train, "type"))
                .category(getText(train, "category"))
                .distance(getInt(train, "distance"))
                .duration(getInt(train, "duration"))
                .avgSpeed(getDouble(train, "avgSpeed"))
                .maxSpeed(getInt(train, "maxSpeed"))
                .totalHalts(getInt(train, "totalHalts"))
                .coachPosition(getText(train, "coachPosition"))

                .currentLocation(mapCurrentLocation(currentLocation))
                .previousHalt(mapStation(previousHalt))
                .nextHalt(mapStation(nextHalt))

                .build();
    }

    /*
     * ==========================
     * CURRENT LOCATION
     * ==========================
     */

    private CurrentLocationResponse mapCurrentLocation(JsonNode node) {

        if (node == null || node.isNull()) {
            return null;
        }

        return CurrentLocationResponse.builder()
                .stationCode(getText(node, "stationCode"))
                .sequence(getInt(node, "sequence"))
                .status(getText(node, "status"))
                .isHalt(getBoolean(node, "isHalt"))
                .isActualPosition(getBoolean(node, "isActualPosition"))
                .segmentProgress(getDouble(node, "segmentProgress"))
                .build();
    }

    /*
     * ==========================
     * PREVIOUS / NEXT HALT
     * ==========================
     */

    private StationResponse mapStation(JsonNode node) {

        if (node == null || node.isNull()) {
            return null;
        }

        return StationResponse.builder()
                .stationCode(getText(node, "stationCode"))
                .stationName(getText(node, "stationName"))
                .sequence(getInt(node, "sequence"))
                .distance(getDouble(node, "distance"))
                .build();
    }

    /*
     * ==========================
     * RUNNING DAYS
     * ==========================
     */

    private List<String> extractRunningDays(JsonNode train) {

        List<String> days = new ArrayList<>();

        JsonNode runningDays = train.get("runningDays");

        if (runningDays == null) {
            return days;
        }

        JsonNode array = runningDays.get("days");

        if (array == null || !array.isArray()) {
            return days;
        }

        Iterator<JsonNode> iterator = array.elements();

        while (iterator.hasNext()) {
            days.add(iterator.next().asText());
        }

        return days;
    }

    /*
     * ==========================
     * TRAIN ROUTE
     * ==========================
     */

    public TrainRouteResponse mapTrainRoute(RailRadarResponse response) {

        if (response == null ||
                !response.success() ||
                response.data() == null) {
            return null;
        }

        JsonNode data = response.data();

        // RailRadar's /trains/{number}/route endpoint returns trainNumber
        // and stops directly on "data" - there is no nested "train" or
        // "route" node.
        JsonNode stops = data.get("stops");
        List<RouteStationResponse> stations = new ArrayList<>();

        if (stops != null && stops.isArray()) {
            for (JsonNode station : stops) {
                stations.add(
                        RouteStationResponse.builder()
                                .sequence(getInt(station, "sequence"))
                                .stationCode(getText(station, "code"))
                                .stationName(getText(station, "name"))
                                .latitude(getDouble(station, "lat"))
                                .longitude(getDouble(station, "lng"))
                                .build()
                );
            }
        }

        return TrainRouteResponse.builder()
                .trainNumber(getText(data, "trainNumber"))
                .totalHalts(stations.isEmpty() ? null : stations.size())
                .route(stations)
                .build();
    }
    /*
     * ==========================
     * COMMON METHODS
     * ==========================
     */
    private String getText(JsonNode node, String field) {
        if (node == null) return null;
        JsonNode value = node.get(field);
        return value == null || value.isNull() ? null : value.asText();
    }
    private Integer getInt(JsonNode node, String field) {
        if (node == null) return null;
        JsonNode value = node.get(field);
        return value == null || value.isNull() ? null : value.asInt();
    }
    private Double getDouble(JsonNode node, String field) {
        if (node == null) return null;
        JsonNode value = node.get(field);
        return value == null || value.isNull() ? null : value.asDouble();
    }
    private Boolean getBoolean(JsonNode node, String field) {
        if (node == null) return null;
        JsonNode value = node.get(field);
        return value == null || value.isNull() ? null : value.asBoolean();
    }
}