package com.railtrack.train.service.impl;

import com.railtrack.common.dto.RailRadarResponse;
import com.railtrack.history.entity.SearchOperation;
import com.railtrack.history.service.SearchHistoryService;
import com.railtrack.train.client.RailRadarClient;
import com.railtrack.train.dto.response.LiveTrainResponse;
import com.railtrack.train.dto.response.TrainDetailsResponse;
import com.railtrack.train.dto.response.TrainRouteResponse;
import com.railtrack.train.mapper.RailRadarMapper;
import com.railtrack.train.service.RailRadarTrainService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class RailRadarTrainServiceImpl implements RailRadarTrainService {

    private static final Logger log =
            LoggerFactory.getLogger(RailRadarTrainServiceImpl.class);

    private final RailRadarClient client;
    private final SearchHistoryService history;
    private final RailRadarMapper mapper;

    public RailRadarTrainServiceImpl(
            RailRadarClient client,
            SearchHistoryService history,
            RailRadarMapper mapper) {

        this.client = client;
        this.history = history;
        this.mapper = mapper;
    }

    @Override
    public TrainDetailsResponse trainDetails(
            String number,
            LocalDate journeyDate,
            String dataType,
            String dataProvider,
            String userId) {

        RailRadarResponse response =
                client.trainDetails(
                        number,
                        journeyDate,
                        dataType,
                        dataProvider,
                        userId);

        record(SearchOperation.TRAIN_DETAILS, number, response);

        return mapper.mapTrainDetails(response);
    }

    @Override
    public LiveTrainResponse liveTrain(
            String number,
            LocalDate date,
            boolean haltsOnly,
            boolean geometry,
            String format,
            boolean includeCoordinates) {

        RailRadarResponse response =
                client.liveTrain(
                        number,
                        date,
                        haltsOnly,
                        geometry,
                        format,
                        includeCoordinates);

        record(
                SearchOperation.LIVE_TRAIN_STATUS,
                number,
                response);

        return mapper.mapLiveTrain(response);
    }

    @Override
    public TrainRouteResponse route(
            String number,
            String format,
            boolean stops) {

        RailRadarResponse response =
                client.route(number, format, stops);

        record(
                SearchOperation.TRAIN_ROUTE_GEOMETRY,
                number,
                response);

        return mapper.mapTrainRoute(response);
    }

    private void record(
            SearchOperation operation,
            String identifier,
            RailRadarResponse response) {

        if (response != null && response.success()) {

            history.save(
                    operation,
                    identifier,
                    null);
        }

        log.info(
                "RailRadar {} completed for {}",
                operation,
                identifier);
    }
}