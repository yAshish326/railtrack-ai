package com.railtrack.train.service;

//import com.railtrack.common.dto.RailRadarResponse;
import com.railtrack.train.dto.response.LiveTrainResponse;
import com.railtrack.train.dto.response.TrainDetailsResponse;
import com.railtrack.train.dto.response.TrainRouteResponse;

import java.time.LocalDate;

/** Domain service for RailRadar train detail, live-status, and route queries. */
public interface RailRadarTrainService {
    TrainDetailsResponse trainDetails(
            String number,
            LocalDate journeyDate,
            String dataType,
            String dataProvider,
            String userId);
    LiveTrainResponse liveTrain(
            String number,
            LocalDate date,
            boolean haltsOnly,
            boolean geometry,
            String format,
            boolean includeCoordinates);

    TrainRouteResponse route(
            String number,
            String format,
            boolean stops);
}
