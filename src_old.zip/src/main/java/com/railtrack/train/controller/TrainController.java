package com.railtrack.train.controller;

import com.railtrack.common.dto.RailRadarResponse;
import com.railtrack.train.dto.response.LiveTrainResponse;
import com.railtrack.train.dto.response.TrainDetailsResponse;
import com.railtrack.train.dto.response.TrainRouteResponse;
import com.railtrack.train.dto.response.TrainSearchResponse;
import com.railtrack.train.service.RailRadarTrainService;
import com.railtrack.train.service.TrainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/v1/train")
@Tag(name = "Train APIs")
public class TrainController {

    private final TrainService trainService;
    private final RailRadarTrainService railRadarTrainService;

    public TrainController(
            TrainService trainService,
            RailRadarTrainService railRadarTrainService) {

        this.trainService = trainService;
        this.railRadarTrainService = railRadarTrainService;
    }

    @Operation(summary = "Search trains between stations")
    @GetMapping("/between-stations")
    public ResponseEntity<TrainSearchResponse> searchTrains(

            @RequestParam
            @NotBlank(message = "Source station is required")
            String from,

            @RequestParam
            @NotBlank(message = "Destination station is required")
            String to,

            @RequestParam
            @NotNull(message = "Journey date is required")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate journeyDate,

            @RequestParam
            @NotBlank(message = "Travel class is required")
            String travelClass,

            @RequestParam
            @NotBlank(message = "Quota is required")
            String quota) {

        return ResponseEntity.ok(
                trainService.searchTrains(
                        from,
                        to,
                        journeyDate,
                        travelClass,
                        quota));
    }

    @Operation(summary = "Train Details")
    @GetMapping("/details/{trainNumber}")
    public ResponseEntity<TrainDetailsResponse> trainDetails(
            @PathVariable String trainNumber,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate journeyDate,

            @RequestParam(required = false)
            String dataType,

            @RequestParam(required = false)
            String dataProvider,

            @RequestParam(required = false)
            String userId) {

        return ResponseEntity.ok(
                railRadarTrainService.trainDetails(
                        trainNumber,
                        journeyDate,
                        dataType,
                        dataProvider,
                        userId));
    }

    @Operation(summary = "Live Train Status")
    @GetMapping("/live/{trainNumber}")
    public ResponseEntity<LiveTrainResponse> liveTrain(

            @PathVariable String trainNumber,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date,

            @RequestParam(defaultValue = "false")
            boolean haltsOnly,

            @RequestParam(defaultValue = "false")
            boolean geometry,

            @RequestParam(defaultValue = "polyline")
            String format,

            @RequestParam(defaultValue = "false")
            boolean includeCoordinates) {

        return ResponseEntity.ok(
                railRadarTrainService.liveTrain(
                        trainNumber,
                        date,
                        haltsOnly,
                        geometry,
                        format,
                        includeCoordinates));
    }

    @Operation(summary = "Train Route Geometry")
    @GetMapping("/route/{trainNumber}")
    public  ResponseEntity<TrainRouteResponse> route(

            @PathVariable String trainNumber,

            @RequestParam(defaultValue = "geojson")
            String format,

            @RequestParam(defaultValue = "true")
            boolean stops) {

        return ResponseEntity.ok(
                railRadarTrainService.route(
                        trainNumber,
                        format,
                        stops));
    }
}