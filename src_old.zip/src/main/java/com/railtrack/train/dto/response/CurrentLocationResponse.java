package com.railtrack.train.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CurrentLocationResponse {

    private Integer sequence;

    private String stationCode;

    private String stationName;

    private String status;

    private Boolean isHalt;

    private Boolean isActualPosition;

    private Double latitude;

    private Double longitude;

    private Double segmentProgress;
}