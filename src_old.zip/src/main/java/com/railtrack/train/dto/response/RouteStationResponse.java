package com.railtrack.train.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RouteStationResponse {

    private Integer sequence;

    private String stationCode;
    private String stationName;

    private Double latitude;
    private Double longitude;

    private Boolean isHalt;

    private String arrival;
    private String departure;

    private Double distance;
}