package com.railtrack.train.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LiveTrainResponse {

    private String trainNumber;
    private String trainName;
    private String trainType;

    private String status;
    private Integer delayMinutes;
    private Integer distance;
    private Integer duration;
    private String coachPosition;

    private Boolean isLive;
    private String trackingMode;

    private String startDate;
    private String lastUpdatedAt;

    private Double avgSpeed;
    private Integer maxSpeed;
    private Integer totalHalts;
    private String category;

    private CurrentLocationResponse currentLocation;

    private StationResponse previousHalt;

    private StationResponse nextHalt;
}