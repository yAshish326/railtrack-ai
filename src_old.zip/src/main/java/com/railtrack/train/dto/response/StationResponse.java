package com.railtrack.train.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StationResponse {

    private Integer sequence;

    private String stationCode;

    private String stationName;

    private String status;

    private String platform;

    private Double distance;

    private String scheduledArrival;

    private String scheduledDeparture;

    private String actualArrival;

    private String actualDeparture;

    private Integer delayMinutes;
}